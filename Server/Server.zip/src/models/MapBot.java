package models;

public class MapBot {

    public int id;
}
