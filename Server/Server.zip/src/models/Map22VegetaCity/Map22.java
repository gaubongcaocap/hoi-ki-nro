package models.Map22VegetaCity;


public class Map22  {

}
