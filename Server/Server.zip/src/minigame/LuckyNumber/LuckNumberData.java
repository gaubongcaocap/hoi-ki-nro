/*
 * Copyright by NTD
 */

package minigame.LuckyNumber;

public class LuckNumberData {
    public long id;
    public int number;
    public boolean isGem;
    public boolean isReward;

    public static class LuckyNumberResul {
        public long id;
        public long money;
        public int number;
        public String text;
    }
}
