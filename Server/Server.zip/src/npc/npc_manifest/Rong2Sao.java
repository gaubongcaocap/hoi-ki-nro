package npc.npc_manifest;

/**
 *
 * @author NTD
 */

public class Rong2Sao extends Rong1Sao {

    public Rong2Sao(int mapId, int status, int cx, int cy, int tempId, int avartar) {
        super(mapId, status, cx, cy, tempId, avartar);
    }

}
