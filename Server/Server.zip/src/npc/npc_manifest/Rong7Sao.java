package npc.npc_manifest;

/**
 *
 * @author NTD
 */

public class Rong7Sao extends Rong1Sao {

    public Rong7Sao(int mapId, int status, int cx, int cy, int tempId, int avartar) {
        super(mapId, status, cx, cy, tempId, avartar);
    }

}
