package matches;

/*
 *
 *
 * @author NTD
 */

public enum TYPE_LOSE_PVP {

    RUNS_AWAY,
    DEAD

}
