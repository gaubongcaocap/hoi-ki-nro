package consts;

import player.Player;

public class cn { 

    private Player player;
    public final static int GIA_X = 1;
    public final static int tileroinr = 30;
    public final static int SV = 1;
    public final static String SDT = "0389000502";
    //public final static int ID_TOPSM = 58240;//SV1
//    public final static int ID_TOPSM = 1598;//SV2
//    public final static int ID_TOPSM = 56868;//SV3
//    public final static int ID_TOPSM = 356;//SV1
    public final static String MANAP = "NTD ";
    public static boolean readInt = false;

    private static class ________________________GHBUG______________________ { 

    }
    public static int ghVnd = 2000000000;
    public static int ghTotalVnd = 40000000;
    public static int ghNgocXanh = 300000000;
    public static int ghNgocHong = 50000000;
    public static int ghThoiVang = 50000000;

    private static class ________________________POTAGE______________________ { 

    }
    public static int costNhanBan = 1000;

    private static class ________________________NPC_TRUNGLINHTHU______________________ { 

    }
    public static int slItemSub = 99;
    public static short itemSub = 2029;
    public static short itemCreat = 2028;
    public static int giaTrung = 5000;
//

    private static class ________________________NPC_THODAICA______________________ { 

    }
    public static short cr = 462;
    public static short thoiVang_k = 1108;
    public static short check_sl_cr = 10;
    public static short get_sl_cr = 10;
    public static int slnx = 5000;
    public static int slnh = 1000;
    public static int slbd = 5;
    public static int slthoiVang_ = 4;

    private static class ________________________NPC_GOHAN_PAGUSU_NAMEC_____________________ { 

    }
    public static int slnx1 = 50000;
    public static int slnh1 = 10000;
//

    private static class ________________________NPC_BARDOCK______________________ { 

    }
    // giá đệ 1
    public static int de1 = 50000 * GIA_X;
    public static int de2 = 70000 * GIA_X;
    public static int de3 = 70000 * GIA_X;
    public static int de4 = 100000 * GIA_X;
    public static int de5 = 120000 * GIA_X;
    public static int de6 = 150000 * GIA_X;
    public static int de7 = 180000 * GIA_X;
    public static int de8 = 200000 * GIA_X;
    //giá đệ vip
    public static int de9 = 300000 * GIA_X;
    public static int de10 = 300000 * GIA_X;
    public static int de11 = 300000 * GIA_X;
    public static int de12 = 400000 * GIA_X;
    public static int de13 = 400000 * GIA_X;
    public static int de14 = 500000 * GIA_X;
    public static int de15 = 500000 * GIA_X;
    public static int de16 = 600000 * GIA_X;
//giá đệ vip 1
    public static int de17 = 50000 * GIA_X;
    public static int de18 = 400000 * GIA_X;
    public static int de19 = 400000 * GIA_X;
    public static int de20 = 550000 * GIA_X;
    public static int de21 = 550000 * GIA_X;
    public static int de22 = 600000 * GIA_X;
    public static int de23 = 600000 * GIA_X;
    public static int de24 = 700000 * GIA_X;
    //giá đệ vip 2
    public static int de25 = 750000 * GIA_X;
    public static int de26 = 800000 * GIA_X;
    public static int de27 = 800000 * GIA_X;
    public static int de28 = 1000000 * GIA_X;
    public static int de29 = 1200000 * GIA_X;
    public static int de30 = 1500000 * GIA_X;
    //giá đệ vip 3
    public static int de31 = 50000 * GIA_X;
    public static int de32 = 70000 * GIA_X;
    public static int de33 = 100000 * GIA_X;
    public static int de34 = 200000 * GIA_X;
    public static int de35 = 500000 * GIA_X;
    public static int de36 = 750000 * GIA_X;
    public static int de37 = 20000 * GIA_X;

    public static int de38 = 50  * GIA_X;
    public static int de39 = 100 * GIA_X;
    public static int de40 = 150 * GIA_X;
    public static int de41 = 200 * GIA_X;
    public static int de42 = 250 * GIA_X;
    public static int de43 = 350 * GIA_X;
    public static int de44 = 750 * GIA_X;
    public static int de45 = 850 * GIA_X;

    public static String petBuuNhiNm = "Bưu Nhí";
    public static String petFideNhiNm = "Fide Nhí";
    public static String petCellNhiNm = "Cell Nhí";
    public static String petAndroidNm = "Android";
    public static String petBuuGayNm = "Bưu Gầy";
    public static String petBerrusNhiNm = "Berrus Nhí";
    public static String petBlackNm = "Black Goku";
    public static String petBerrusNm = "Berrus Hủy Diệt";

    //giá đổi skill
    public static int skill23 = 3000;
    public static int skill24 = 10000;
    //giá đổi vnd
    public static short thoivang = 457;

    public static int giaVND_1 = 20000;
    public static int thoiVang_1 = 50;
    public static int nx1 = 2000000;
    public static int nh1 = 40000;

    public static int giaVND_2 = 50000;
    public static int thoiVang_2 = 150;
    public static int nx2 = 2000000;
    public static int nh2 = 100000;

    public static int giaVND_3 = 100000;
    public static int thoiVang_3 = 300;
    public static int nx3 = 4500000;
    public static int nh3 = 200000;

    public static int giaVND_4 = 200000;
    public static int thoiVang_4 = 700;
    public static int nx4 = 9000000;
    public static int nh4 = 500000;

    public static int giaVND_5 = 500000;
    public static int thoiVang_5 = 2000;
    public static int nx5 = 20000000;
    public static int nh5 = 40;

    private static class ________________________NPC_BAHATMIT______________________ { 

    }

    //Nâng bông tai 2
    public static short thoiVang_NangPotara2 = 100;
    public static short slManhVoPotara2 = 9999;
    public static short subManhVoPotara2 = 4999;
    public static int vangNangPotara = 500000000;
    public static int gemNangPotara = 2000;

    //Mở chỉ số btc2
    public static short thoiVangOpenPotara = 20;
    public static short manhHonOpenPotara = 99;
    public static short daXanhLamOpenPotara = 10;
    public static int goldOpenPotara = 500000000;
    public static int gemOpenPotara = 3000;

    //ép sao trang bị
    public static short thoiVang_EpSao = 2;

    private static class ________________________Chỉ_số_hợp_thể_đệ______________________ { 

    }
    public static short hpPet = 20;
    public static short mpPet = 20;
    public static short damePet = 20;

    public static short hpPet1 = 20;
    public static short mpPet1 = 20;
    public static short damePet1 = 20;

    public static short hpPet2 = 30;
    public static short mpPet2 = 20;
    public static short damePet2 = 25;

    public static short hpPet3 = 30;
    public static short mpPet3 = 25;
    public static short damePet3 = 25;

    public static short hpPet4 = 35;
    public static short mpPet4 = 35;
    public static short damePet4 = 25;

    public static short hpPet5 = 40;
    public static short mpPet5 = 30;
    public static short damePet5 = 30;

    public static short hpPet6 = 30;
    public static short mpPet6 = 30;
    public static short damePet6 = 30;

    public static short hpPet7 = 40;
    public static short mpPet7 = 40;
    public static short damePet7 = 35;

    public static short hpPet8 = 50;
    public static short mpPet8 = 50;
    public static short damePet8 = 40;

    //
    public static short hpPet9 = 55;
    public static short mpPet9 = 55;
    public static short damePet9 = 45;

    public static short hpPet10 = 65;
    public static short mpPet10 = 65;
    public static short damePet10 = 55;

    public static short hpPet11 = 70;
    public static short mpPet11 = 70;
    public static short damePet11 = 60;

    public static short hpPet12 = 85;
    public static short mpPet12 = 85;
    public static short damePet12 = 65;

    public static short hpPet13 = 90;
    public static short mpPet13 = 90;
    public static short damePet13 = 75;

    public static short hpPet14 = 60;
    public static short mpPet14 = 80;
    public static short damePet14 = 90;

    public static short hpPet15 = 100;
    public static short mpPet15 = 100;
    public static short damePet15 = 60;

    public static short hpPet16 = 100;
    public static short mpPet16 = 100;
    public static short damePet16 = 90;

    public static short hpPet17 = 95;
    public static short mpPet17 = 95;
    public static short damePet17 = 80;

    public static short hpPet18 = 110;
    public static short mpPet18 = 110;
    public static short damePet18 = 95;

    public static short hpPet19 = 60;
    public static short mpPet19 = 60;
    public static short damePet19 = 80;

    public static short hpPet20 = 60;
    public static short mpPet20 = 60;
    public static short damePet20 = 45;

    public static short hpPet21 = 90;
    public static short mpPet21 = 90;
    public static short damePet21 = 100;

    public static short hpPet22 = 50;
    public static short mpPet22 = 50;
    public static short damePet22 = 110;

    public static short hpPet23 = 110;
    public static short mpPet23 = 110;
    public static short damePet23 = 100;

    public static short hpPet24 = 130;
    public static short mpPet24 = 130;
    public static short damePet24 = 90;

    public static short hpPet25 = 80;
    public static short mpPet25 = 80;
    public static short damePet25 = 110;

    public static short hpPet26 = 150;
    public static short mpPet26 = 90;
    public static short damePet26 = 100;

    public static short hpPet27 = 0;
    public static short mpPet27 = 0;
    public static short damePet27 = 120;

    public static short hpPet28 = 115;
    public static short mpPet28 = 115;
    public static short damePet28 = 110;

    public static short hpPet29 = 140;
    public static short mpPet29 = 160;
    public static short damePet29 = 85;

    public static short hpPet30 = 80;
    public static short mpPet30 = 80;
    public static short damePet30 = 130;

    public static short hpPet31 = 100;
    public static short mpPet31 = 160;
    public static short damePet31 = 140;

    public static short hpPet32 = 180;
    public static short mpPet32 = 160;
    public static short damePet32 = 150;

    public static short hpPet33 = 170;
    public static short mpPet33 = 170;
    public static short damePet33 = 170;

    public static short hpPet35 = 33;
    public static short mpPet35 = 34;
    public static short damePet35 = 34;

    public static short hpPet36 = 33;
    public static short mpPet36 = 34;
    public static short damePet36 = 34;

    public static short hpPet37 = 33;
    public static short mpPet37 = 34;
    public static short damePet37 = 34;

    private static class ________________________QUÀ_SK_QUY_LAO______________________ {
    }
    public static int daquy1 = 2162;
    public static int daquy2 = 2163;
    public static int daquy3 = 2164;
    public static int daquy4 = 2165;
    public static int daquy5 = 2166;

    public static int hopKHHD = 2115;
    public static int hopKHTL = 2114;

    public static int nr1s = 14;
    public static int nr2s = 15;
    public static int nr3s = 16;
    public static int nr4s = 17;
    public static int nr5s = 18;
    public static int nr6s = 19;
    public static int nr7s = 20;

//_______________________________________________________________________________________________
//    TOP 1
    public static int top1_1 = 1348;
    public static short sltop1_1 = 1;
    public static int cs_top1_1_1 = 34;
    public static int cs_top1_1_2 = 26;
    public static int cs_top1_1_3 = 13;

    public static int top1_2 = 1467;
    public static int sltop1_2 = 99;
    public static int sl_daquy_top1 = 99;

    public static int sl_hopKH_top1 = 3;

    public static int sl_nr_top1 = 15;

    //    TOP 2
    public static int top2_1 = 1467;
    public static short sltop2_1 = 99;
//    public static int cs_top2_1_1 = 80;
    public static int sl_daquy_top2 = 66;

    public static int sl_hopKH_top2 = 2;

    public static int sl_nr_top2 = 10;

    //    TOP 3
    public static int top3_1 = 1467;
    public static short sltop3_1 = 66;
//    public static int cs_top3_1_1 = 75;
    public static int sl_daquy_top3 = 20;

    public static int sl_hopKH_top3 = 1;

    public static int sl_nr_top3 = 8;

    //TOP 4
    public static int sl_nr_top4 = 5;

    public static String[] TextQuestion = new String[]{
        "|3|Ngày Quốc khánh của Việt Nam là ngày nào?\n"
        + "A. 19/8/1945\n"
        + "B. 2/9/1945\n"
        + "C. 30/4/1975\n"
        + "D. 7/5/1954", // "B" // Đáp án đúng

        "|3|Chủ tịch Hồ Chí Minh đã đọc bản Tuyên ngôn Độc lập tại đâu vào ngày 2/9/1945?\n"
        + "A. Quảng trường Ba Đình\n"
        + "B. Phủ Chủ tịch\n"
        + "C. Lăng Chủ tịch Hồ Chí Minh\n"
        + "D. Cột cờ Hà Nội", // "A" // Đáp án đúng

        "|3|Quốc khánh Việt Nam lần đầu tiên được tổ chức vào năm nào?\n"
        + "A. 1945\n"
        + "B. 1946\n"
        + "C. 1954\n"
        + "D. 1975", // "A" // Đáp án đúng

        "|3|Tuyên ngôn Độc lập của Việt Nam được Hồ Chí Minh đọc tại đâu?\n"
        + "A. Nhà Rông\n"
        + "B. Nhà sàn Bác Hồ\n"
        + "C. Số nhà 48 Hàng Ngang\n"
        + "D. Quảng trường Ba Đình", // "D" // Đáp án đúng

        "|3|Trong bản Tuyên ngôn Độc lập, Hồ Chí Minh đã trích dẫn tuyên ngôn của quốc gia nào?\n"
        + "A. Mỹ\n"
        + "B. Pháp\n"
        + "C. Anh\n"
        + "D. Mỹ và Pháp", // "D" // Đáp án đúng

        "|3|Ngày Quốc khánh Việt Nam 2/9 được công nhận là ngày nghỉ lễ vào năm nào?\n"
        + "A. 1945\n"
        + "B. 1946\n"
        + "C. 1954\n"
        + "D. 1975", // "B" // Đáp án đúng

        "|3|Ai là người phát động Phong trào Cách mạng tháng Tám dẫn đến ngày Quốc khánh 2/9?\n"
        + "A. Trường Chinh\n"
        + "B. Hồ Chí Minh\n"
        + "C. Võ Nguyên Giáp\n"
        + "D. Lê Duẩn", // "B" // Đáp án đúng

        "|3|Bản Tuyên ngôn Độc lập của Việt Nam được viết theo thể loại nào?\n"
        + "A. Thơ ca\n"
        + "B. Truyện ngắn\n"
        + "C. Văn xuôi chính luận\n"
        + "D. Tiểu thuyết", // "C" // Đáp án đúng

        "|3|Quốc khánh 2/9 còn được gọi là ngày gì?\n"
        + "A. Ngày chiến thắng\n"
        + "B. Ngày giải phóng\n"
        + "C. Ngày Độc lập\n"
        + "D. Ngày toàn quốc kháng chiến", // "C" // Đáp án đúng

        "|3|Bản Tuyên ngôn Độc lập của Việt Nam bắt đầu với câu nào?\n"
        + "A. \"Hỡi đồng bào cả nước!\"\n"
        + "B. \"Tất cả mọi người sinh ra đều có quyền bình đẳng.\"\n"
        + "C. \"Tất cả mọi người sinh ra đều có quyền sống, quyền tự do và quyền mưu cầu hạnh phúc.\"\n"
        + "D. \"Độc lập, Tự do, Hạnh phúc.\"", // "C" // Đáp án đúng

        "|3|Ai là người soạn thảo bản Tuyên ngôn Độc lập của Việt Nam?\n"
        + "A. Trường Chinh\n"
        + "B. Võ Nguyên Giáp\n"
        + "C. Phạm Văn Đồng\n"
        + "D. Hồ Chí Minh", // "D" // Đáp án đúng

        "|3|Sự kiện nào đã mở đầu cho cuộc cách mạng tháng Tám tại Hà Nội?\n"
        + "A. Khởi nghĩa Bắc Sơn\n"
        + "B. Khởi nghĩa Nam Kỳ\n"
        + "C. Biểu tình ngày 19/8/1945\n"
        + "D. Tổng tiến công Xuân Mậu Thân 1968", // "C" // Đáp án đúng

        "|3|Quốc khánh 2/9 là sự kiện đánh dấu điều gì?\n"
        + "A. Chiến thắng Điện Biên Phủ\n"
        + "B. Thống nhất đất nước\n"
        + "C. Sự ra đời của nước Việt Nam Dân chủ Cộng hòa\n"
        + "D. Sự kết thúc chiến tranh chống Mỹ", // "C" // Đáp án đúng

        "|3|Ai là người đã đọc Tuyên ngôn Độc lập vào ngày 2/9/1945?\n"
        + "A. Phạm Văn Đồng\n"
        + "B. Võ Nguyên Giáp\n"
        + "C. Hồ Chí Minh\n"
        + "D. Trường Chinh", // "C" // Đáp án đúng

        "|3|Tuyên ngôn Độc lập của Việt Nam trích dẫn từ tuyên ngôn của nước nào?\n"
        + "A. Hoa Kỳ\n"
        + "B. Pháp\n"
        + "C. Hoa Kỳ và Pháp\n"
        + "D. Nga", // "C" // Đáp án đúng

        "|3|Quốc khánh Việt Nam 2/9 là dịp để người dân tưởng nhớ ai?\n"
        + "A. Các anh hùng liệt sĩ\n"
        + "B. Các nhà cách mạng\n"
        + "C. Hồ Chí Minh\n"
        + "D. Tất cả các đáp án trên", // "D" // Đáp án đúng

        "|3|Ngày Quốc khánh 2/9/1945, nước Việt Nam Dân chủ Cộng hòa được thành lập tại đâu?\n"
        + "A. Hà Nội\n"
        + "B. Huế\n"
        + "C. Sài Gòn\n"
        + "D. Điện Biên Phủ", // "A" // Đáp án đúng

        "|3|Sự kiện nào diễn ra vào ngày 2/9/1945?\n"
        + "A. Bác Hồ đọc Tuyên ngôn Độc lập\n"
        + "B. Khởi nghĩa Bắc Sơn\n"
        + "C. Thành lập Đảng Cộng sản Việt Nam\n"
        + "D. Tổng khởi nghĩa giành chính quyền", // "A" // Đáp án đúng

        "|3|Ngày Quốc khánh Việt Nam 2/9 được tổ chức lần đầu vào năm nào?\n"
        + "A. 1945\n"
        + "B. 1946\n"
        + "C. 1954\n"
        + "D. 1975", // "B" // Đáp án đúng

        "|3|Quảng trường Ba Đình, nơi diễn ra lễ Quốc khánh 2/9, nằm ở đâu?\n"
        + "A. Hà Nội\n"
        + "B. Huế\n"
        + "C. Sài Gòn\n"
        + "D. Hải Phòng" // "A" // Đáp án đúng
    };

}
