package boss;

/*
 *
 *
 * @author NTD
 */

public enum AppearType {

    DEFAULT_APPEAR,
    APPEAR_WITH_ANOTHER,
    ANOTHER_LEVEL,
    CALL_BY_ANOTHER

}
