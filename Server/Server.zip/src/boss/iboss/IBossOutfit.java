package boss.iboss;

/*
 *
 *
 * @author NTD
 */

public interface IBossOutfit {

    short getHead();

    short getBody();

    short getLeg();

    short getFlagBag();

    byte getAura();

    byte getEffFront();
}
