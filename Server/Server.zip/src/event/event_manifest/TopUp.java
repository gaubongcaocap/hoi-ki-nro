package event.event_manifest;

/**
 *
 * @author NTD
 */

import consts.ConstNpc;
import event.Event;

public class TopUp extends Event {

    @Override
    public void npc() {
    }

}
