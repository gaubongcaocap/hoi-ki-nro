package event.event_manifest;

/**
 *
 * @author NTD
 */

import boss.BossID;
import event.Event;

public class Default extends Event {

    @Override
    public void boss() {
//        createBoss(BossID.SUPER_BROLY, 5);
    }

}
