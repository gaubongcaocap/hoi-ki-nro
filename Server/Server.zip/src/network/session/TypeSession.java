package network.session;

/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TypeSession
/*    */ {
/* 10 */   SERVER,
/* 11 */   CLIENT;
/*    */ }


/* Location:              C:\Users\VoHoangKiet\Downloads\TEA_V5\lib\GirlkunNetwork.jar!\com\girlkun\network\session\TypeSession.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */